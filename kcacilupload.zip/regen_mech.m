function [ct,pop] = regen_mech(NP, dim,t,G,up,low)    
NN = round(N * tao);
[~,index]=sort(fitnessP);
i=1:NN;
Sup_Pop(i,:) = P(index(i),:);
 mu= mean(P,1);
 ct = (Sup_Pop - repmat(mu,size(Sup_Pop,1),1))' * (Sup_Pop - repmat(mu,size(Sup_Pop,1),1));
 ct = ct/(size( Sup_Pop, 1));
 ct = (ct + ct.') / 2;
 newr = mvnrnd(0,1,N);
 trim=chol(ct);
 entamax=0.01*(up-low);
 entamin=entamax/10;
 beta=1-exp(-(t/0.15*G));
 enta=entamin+(betamax-betamin)*((G-t)/G)^beta;
 popl=mu+enta*trim*mewr;

