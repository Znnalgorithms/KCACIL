clc;
clear all;

format long;
format compact;

Results_10=[];
Results_30=[];
Results_50=[];
Results_100=[];


% Method_Name = 'EDE';
% Method_Name = 'SHADE';
% Method_Name = 'SHADE_SPA';
% Method_Name = 'ESHADE';
% Method_Name = 'ESHADE_SPA';
% Method_Name = 'LSHADE';
% Method_Name = 'LSHADE_SPA';
% Method_Name = 'ELSHADE';
% Method_Name = 'ELSHADE_SPA';
% Method_Name = 'LSHADE_SPACMA';


% Method_Name = 'LSHADE_Current2Best1';
% Method_Name = 'ELSHADE_Top10pest';

% Method_Name = 'LSHADE_Tri';
% Method_Name = 'ESHADE_Top10pest';
% Method_Name = 'EDE_Top10pest_Only';


% Method_Name = 'EB_DE';
% Method_Name = 'EB_EBDE';
% Method_Name = 'EB_SHADE';
% Method_Name = 'EB_LSHADE';


% Method_Name = 'EB_LSHADE_SPACMA';
% Method_Name = 'EB_LSHADE_cnEpSin';
% Method_Name = 'EB_LSHADE';


for func = [1 3:30]
    problem_size =10;
    file_name=sprintf('Results\\%s_CEC2017_Problem#%s_Problem_Size#%s',Method_Name,int2str(func),int2str(problem_size));
    load(file_name);
    Results_10(func,:)= mean(funcval_out);

    
    problem_size =30;
    file_name=sprintf('Results\\%s_CEC2017_Problem#%s_Problem_Size#%s',Method_Name,int2str(func),int2str(problem_size));
    load(file_name);
    Results_30(func,:)= mean(funcval_out);

    %
    problem_size =50;
    file_name=sprintf('Results\\%s_CEC2017_Problem#%s_Problem_Size#%s',Method_Name,int2str(func),int2str(problem_size));
    load(file_name);
    Results_50(func,:)= mean(funcval_out);

% %     
    problem_size =100;
    file_name=sprintf('Results\\%s_CEC2017_Problem#%s_Problem_Size#%s',Method_Name,int2str(func),int2str(problem_size));
    load(file_name);
    Results_100(func,:)= mean(funcval_out);

    
end %% end 1 function run

All_Results=[Results_10,Results_30,Results_50,Results_100];


All_Results(All_Results<10^-8)=0;

file_name=sprintf('%s_30_100.txt',Method_Name);
save(file_name, 'All_Results', '-ascii');



