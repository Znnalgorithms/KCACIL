function [popi] = rev_inf(N,up,low,zeta)      
for i=1:N
avgP1=sum(P1)/N;
fitnessavgP1=ObjFun(P1,func);
avgd1=(sum(P1-avgP1))/N;
deltaf1=sum(fitnessP1-fitnessavgP1)/N;
lamda=sqrt(sum((up-low)/N)^2);
dens1=deltaf1*(1+lamda/avgd1);
if dens1<10^-5 
P1=P1+zeta*(avgP1-P1);
worstX=worstX+zeta*(avgP1-worstX);
end
end
for i=N+1:2N
avgP2=sum(P2)/N;
fitnessavgP2=ObjFun(P2,func);
avgd2=(sum(P2-avgP2))/N;
deltaf2=sum(fitnessP2-fitnessavgP2)/N;
lamda=sqrt(sum((up-low)/N)^2);
dens2=deltaf2*(1+lamda/avgd2);
if dens2<10^-5 
P2=P2+zeta*(avgP2-P2);
worstX=worstX+zeta*(avgP2-worstX);
end
end
for i=2N+1:3N
avgP3=sum(P3)/N;
fitnessavgP3=ObjFun(P3,func);
avgd3=(sum(P3-avgP3))/N;
deltaf3=sum(fitnessP3-fitnessavgP3)/N;
lamda=sqrt(sum((up-low)/N)^2);
dens3=deltaf3*(1+lamda/avgd3);
if dens3<10^-5 
P3=P3+zeta*(avgP3-P3);
worstX=worstX+zeta*(avgP3-worstX);
end
end

