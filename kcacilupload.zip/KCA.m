%%%%%%%%%%%%%%%%%%%
clc;
clear;
DIM_RATE=1;
for D=[10] 
  if D==10
     G=2000;
%      MaxIter=3333;
  end
   if D==30
     G=6000; 
%      MaxIter=10000;
   end
   if D==50
     G=10000;
%      MaxIter=16666; 
   end
   if D==100
     G=20000;
%      MaxIter=33333;
   end
   low=-100*ones(1,D);
   up=100*ones(1,D);
    for func=[1]
        N=50;
% max_nfes = 10000 * D;
% nfes = 0;
runs=1;
next_globalminmum=Inf;
gbest=zeros(runs,G);
pbest=zeros(G,runs);
% STD=zeros(G,D);
fprintf('\n-------------------------------------------------------\n')
fprintf('Function = %d, Dimension size = %d\n', func, D)
for r=1:runs

w=0.2;
P=GeneratePopulation(N,D,low,up); 
oldP=GeneratePopulation(N,D,low,up);
fitnessP=ObjFun(P,func);
[~,idx]=sort(fitnessP);
first=idx(1,1:8);
second=idx(1,9:42);
third=idx(1,43:end);
%%%three population
P1=P(first',:);
P2=P(second',:);
P3=P(third',:);
n1=size(P1,1);
n2=size(P2,1);
n3=size(P3,1);
oldP1=oldP(1:n1,:);
oldP2=oldP(n1+1:n1+n2,:);
oldP3=oldP(n1+n2+1:end,:);
fitnessP1=fitnessP(first);
fitnessP2=fitnessP(second);
fitnessP3=fitnessP(third);
tbl_0=tabulate(fitnessP2);
b0=tbl_0(:,2);
if sum(b0==1)==n2
    probability1_0=1/n2;
    entropy2_0=n2*(-log2(probability1_0)*probability1_0);
elseif sum(b0==1)~=n2
    probability1_0=(sum(b0==1))/n2;
    probability2_0=(sum(b0~=1))/n2;
    entropy2_0=(-log2(probability1_0)*probability1_0)+(-log2(probability2_0)*probability2_0);
end
for t=1:G
            StdP=std(P);
            StdoldP=std(oldP);
            [~,indexbestX]=min(fitnessP);
            bestX=P(indexbestX,:);

            for i=1:n1
                if rand<rand
                    oldP1=P1;
                end
                oldP1=oldP1(randperm(n1),:);
                StdoldP1=std(oldP1);
                scoreoldP1=0;
                indoldx1=StdoldP1<StdoldP;
                scoreoldP1=scoreoldP1+sum(indoldx1==1);              
            map1=ones(n1,D); 
            
            if rand<rand
                for i1=1:n1  
                    u=randperm(D); 
                    map1(i1,u(1:ceil(DIM_RATE*rand*D)))=0; 
                end
            else
                for i1=1:n1  
                    map1(i1,randi(D))=0; 
                end
            end
            for m=1:n1
                a=1;
                b=n1;
                dx=randperm(b-a+1)+a-1;
                r1=dx(1);
                r2=dx(2);
                r3=dx(3);
                if r1==m
                    r1=dx(4);
                elseif r2==m
                    r2=dx(4);
                elseif r3==m
                    r3=dx(4);
                end
%             end
       
        if t<rand*G
            F=scale_factor2;
            T1=P1+(map1.*F).*(P1(r1,:)-P1)+(map1.*F*w).*(oldP1(r2,:)-oldP1(r3,:));
        elseif t>=rand*G
            F=scale_factor1;
            T1=P1+(map1.*F).*(bestX-P1);
        end
            T1=BoundaryControl(T1,low,up);
       
            fitnessT1=ObjFun(T1,func);

            if size(fitnessT1,1)~=size(fitnessP1,1)
                disp('行出错');
            end
            if size(fitnessT1,2)~=size(fitnessP1,2)
                disp('列出错');
            end
            ind1=fitnessT1<fitnessP1;
            fitnessP1(ind1)=fitnessT1(ind1);
            P1(ind1,:)=T1(ind1,:);
            [globalminimum1_best,ind1_min]=min(fitnessP1);
            [globalminimum1_worst,ind1_max]=max(fitnessP1);
            bextP1=P1(ind1_min,:);
            [~,idx]=sort(fitnessP1);
            second_idxP=idx(1,2);
            second_bextP1=P1(second_idxP',:);
            end
            end
            for i=1:n2
                tbl=tabulate(fitnessP2);
                b=tbl(:,2);
                if sum(b==1)==n2
                    probability1=1/n2;
                    entropy=n2*(-log2(probability1)*probability1);
                elseif sum(b==1)~=n2
                    probability1=(sum(b==1))/n2;
                    probability2=(sum(b~=1))/n2;
                    entropy=(-log2(probability1)*probability1)+(-log2(probability2)*probability2);
                end
                document_entropy(1,t)=entropy;
%                 fprintf('interation = %d\n', t);
%                 disp(b);
                if rand<rand
                    oldP2=P2;
                end
                oldP2=oldP2(randperm(n2),:);
%                 if (fitnessP2(i)>= fvag2)&&(nfes<=max_nfes/2)
                StdoldP2=std(oldP2);
                scoreoldP2=0;
                indoldx2=StdoldP2<StdoldP;
                scoreoldP2=scoreoldP2+sum(indoldx2==1);
                StdP2=std(P2);
                scoreP2=0;
                indx2=StdP2<StdP;
                scoreP2=scoreP2+sum(indx2==1);
%                 if (fitnessP2(i)>= fvag2)&&(t<=G/2)
%                     F=scale_factor2;
%                 else
%                     F=scale_factor1;
%                 end
%                 if fitnessP2(i)<= fvag2
%                     w2 = wmax - (fitnessP2-fmin2)*(wmax-wmin)/(fvag2-fmin2);
%                 else
%                     w2 = wmax;
%                 end
%                 w2=min(w2);
%                 w2=wmax-rand*(-(sin(pi/(2*t))+wmin));
                map2=ones(n2,D); 
           
            if rand<rand
                for i2=1:n2  
                    u=randperm(D); 
                    map2(i2,u(1:ceil(DIM_RATE*rand*D)))=0; 
                end
            else
                for i2=1:n2 
                    map2(i2,randi(D))=0; 
                end
            end
%             end
        
            for k=1:n2
                a=1;
                b=n2;
                dx=randperm(b-a+1)+a-1;
                r1=dx(1);
                r2=dx(2);
                r3=dx(3);
                if r1==k
                    r1=dx(4);
                elseif r2==k
                    r2=dx(4);
                elseif r3==k
                    r3=dx(4);
                end
%                 if t<rand*G
                if entropy>0.95*entropy2_0
                    F=scale_factor2;
                    T2=P2+(map2.*F*w).*(P2(r2,:)-P2)+(map2.*F*w).*(oldP2(r2,:)-oldP2(r3,:));
%                 elseif t>=rand*G
                elseif entropy<=0.95*entropy2_0
                    F=scale_factor1;
                    T2=P2+(map2.*F*w).*(second_bextP1-oldP2(r1,:));
                end
%             T2=P2+(map2.*F*w2).*(oldP2(r1,:)-oldP2(r2,:));
%             T2=P2+(map2.*F*w2).*(second_bextP1-oldP2(r1,:));
%             T2=P2+(map2.*F*w2).*(second_bextP1-oldP2);
            T2=BoundaryControl(T2,low,up);
       
            fitnessT2=ObjFun(T2,func);
%             fitnessT2=Sphere(T2);
%             fitnessT2=ackley(T2);
%             fitnessT2=rastrigin(T2);
%             fitnessT2=rosenbrock(T2);
%             if nfes>max_nfes
%                 break;
%             end
%             nfes=nfes+1;
            if size(fitnessT2,1)~=size(fitnessP2,1)
                disp('行出错');
            end
            if size(fitnessT2,2)~=size(fitnessP2,2)
                disp('列出错');
            end
            
            ind2=fitnessT2<fitnessP2;
           
            Variable_Num=sum(ind2==0);
            Probability_Vector=zeros(1,D);
            fitnessP2(ind2)=fitnessT2(ind2);
            P2(ind2,:)=T2(ind2,:);
           
            A=P2(ind2==0,:);
            B=bestX;
            meanP2=mean(P2);
            dis_condition=abs((meanP2-B));
            for i4=1:Variable_Num
                for j=1:D
                    dis(i4,j)=abs(A(i4,j)-B(1,j));
                    ind_condition(i4,j)=dis(i4,j)<dis_condition(1,j);
                end
            end 
             
             Ones_Number=zeros(1,D);
             for i5=1:Variable_Num
                     for j1=1:1:D
                         if ind_condition(i5,j1)==1
                             Ones_Number(1,j1)=Ones_Number(1,j1)+1;
                         end
                     end
             end
             for i6=1:D
                 Probability_Vector(1,i6)=Ones_Number(1,i6)/Variable_Num;
             end 
            
             for i7=1:Variable_Num
                 for j=1:D
                         if Probability_Vector(1,j)<0.5
                             A(i7,j)=bestX(1,j);
                         end
                 end
             end
            [globalminimum2_best,ind2_min]=min(fitnessP2);
            [globalminimum2_worst,ind2_max]=max(fitnessP2);
%             if globalminimum2_worst<globalminimum1_best
% %                 P1(ind1_min,:)=P2(ind2_max,:);
%                 P1(ind1_max,:)=P2(ind2_min,:);
% %                 [~,idx2]=sort(fitnessP2);
% %                 first_change=idx2(1,1:n1);
% %                 P1=P2(first_change',:);
%             end
            if globalminimum2_worst<globalminimum1_worst&&globalminimum2_best<globalminimum1_best
                P1(ind1_min,:)=P2(ind2_min,:);
                P1(ind1_max,:)=P2(ind2_max,:);
            end
            end
            end
            
            for i=1:n3
                if rand<rand
                    oldP3=P3;
                end
                oldP3=oldP3(randperm(n3),:);
%                 if (fitnessP3(i)>= fvag3)&&(nfes<=max_nfes/2)
                StdoldP3=std(oldP3);
                scoreoldP3=0;
                indoldx3=StdoldP3<StdoldP;
                scoreoldP3=scoreoldP3+sum(indoldx3==1);
                fvag3=mean(fitnessP3);
                if (fitnessP3(i)>= fvag3)&&(t<=G/2)
                    F=scale_factor2;
                else
                    F=scale_factor1;
                end
%                 if fitnessP3(i)<= fvag3
%                     w3 = wmax - (fitnessP3-fmin3)*(wmax-wmin)/(fvag3-fmin3);
%                 else
%                     w3 = wmax;
%                 end
%                 w3=min(w3);
%                 w3=wmax-rand*(-(sin(pi/(2*t))+wmin));
                map3=ones(n3,D); 
            
            if rand<rand
                for i3=1:n3  
                    u=randperm(D); 
                    map3(i3,u(1:ceil(DIM_RATE*rand*D)))=0; 
                end
            else
                for i3=1:n3 
                    map3(i3,randi(D))=0; 
                end
            end
%             end
       
            for l=1:n3
                a=1;
                b=n1;
                dx=randperm(b-a+1)+a-1;
                r1=dx(1);
                r2=dx(2);
                r3=dx(3);
                if r1==l
                    r1=dx(4);
                elseif r2==l
                    r2=dx(4);
                elseif r3==l
                    r3=dx(4);
                end
        if t<rand*G
            T3=P3+(map3.*F*w).*(P3(r1,:)-P3)+(map3.*F*w).*(oldP3(r2,:)-oldP3(r3,:));
        elseif t>=rand*G
            T3=P3+(map3.*F*w).*(bextP1-oldP3);
        end
%             T3=P3+(map3.*F*w3).*(bextP1-oldP3);
            T3=BoundaryControl(T3,low,up);
        
            fitnessT3=ObjFun(T3,func);
%             fitnessT3=Sphere(T3);
%             fitnessT3=ackley(T3);
%             fitnessT3=rastrigin(T3);
%             fitnessT3=rosenbrock(T3);
%             if nfes>max_nfes
%                 break;
%             end
%             nfes=nfes+1;
            if size(fitnessT3,1)~=size(fitnessP3,1)
                disp('行出错');
            end
            if size(fitnessT3,2)~=size(fitnessP3,2)
                disp('列出错');
            end
            
            ind3=fitnessT3<fitnessP3;
            fitnessP3(ind3)=fitnessT3(ind3);
            P3(ind3,:)=T3(ind3,:);
            [globalminimum3_best,ind3_min]=min(fitnessP3);
            [globalminimum3_worst,ind3_max]=max(fitnessP3);
%             if globalminimum3_worst<globalminimum2_best
% %                P2(ind2_min,:)=P3(ind3_max,:);
%                P2(ind2_max,:)=P3(ind3_min,:);
% %                 [~,idx3]=sort(fitnessP3);
% %                 second_change=idx3(1,1:n3);
% %                 P2=P3(second_change',:);
%             end
            if globalminimum3_worst<globalminimum2_worst&&globalminimum3_best<globalminimum2_best
                P2(ind2_min,:)=P3(ind3_min,:);
                P2(ind2_max,:)=P3(ind3_max,:);
            end
            end
            end
            globalminimum=min([globalminimum1_best,globalminimum2_best,globalminimum3_best]);
%             P_temp=[P1;P2;P3];
            P=[P1;P2;P3];
%             StdP_temp=std(P_temp);
%             STD(t,:)=StdP_temp;
            fitness_temp=[fitnessP1,fitnessP2,fitnessP3];
            [~,idx_temp]=sort(fitness_temp);
            P1_change=idx_temp(1,1:n1);
%             P1=P_temp(P1_change',:);
            P1=P(P1_change',:);
            P2_change=idx_temp(1,n1+1:n1+n2);
            if (t<G/2) && (scoreP2/D)>0.5
%                 P2=P_temp(P2_change',:);
                P2=P(P2_change',:);
            end
            subscore={scoreoldP1,scoreoldP2,scoreoldP3};
            for l=1:3
                if subscore{l}/D>0.5 || globalminimum==next_globalminmum
                    oldP=[oldP1;oldP2;oldP3];
                    oldP=oldP(randperm(N),:);
                    oldP1=oldP(1:n1,:);
                    oldP2=oldP(n1+1:n1+n2,:);
                    oldP3=oldP(n1+n2+1:end,:);
                end
            end
            next_globalminmum=globalminimum;
%             globalminimizer=P(ind,:);
%             bestsolution=[bestsolution;n globalminimum];
%             assignin('base','globalminimizer',globalminimizer);
            assignin('base','globalminimum',globalminimum);
            assignin('base','gbest',gbest);
            %assignin('base','std',STD);
            assignin('base','P2',P2);
            assignin('base','document_entropy',document_entropy);
%             if nfes>max_nfes
%                 break;
%             end
            gval=globalminimum-func*100;
            gbest(r,t)=gval;
            pbest(t,r)=gval;
%         gbest=vertcat(gbest,globalminimum);
%      plot(bestsolution(:,1),bestsolution(:,2),'r');
% save('D:\MatlabCode\KCACIL\gbest.txt','gval','-ascii','-append');
end
fprintf('KCACIL|%5.0f -----> %9.16f\n',r,globalminimum);
if D==10
    xlswrite('KCACIL_10D.xlsx',pbest,func);
end
if D==30
    xlswrite('KCACIL_30D.xlsx',pbest,func);
end
if D==50
    xlswrite('KCACIL_50D.xlsx',pbest,func);
end
if D==100
    xlswrite('KCACIL_100D.xlsx',pbest,func);
end
file_name=sprintf('gbest\\KCACIL_%s_%s.txt',int2str(func),int2str(D));
save(file_name, 'gval', '-ascii','-append');
end
% Mean=mean(gbest(:,end));
% Std=std(gbest(:,end));
% save('D:\MatlabCode\KCACIL\Mean.txt','Mean','-ascii','-append');
% save('D:\MatlabCode\KCACIL\Std.txt','Std','-ascii','-append');
Mean=mean(gbest(:,end));
Std=std(gbest(:,end));
Max=max(gbest(:,end));
Min=min(gbest(:,end));
Median=median(gbest(:,end));
fprintf('Mean =%g Std=%g max =%g min=%g median =%g\n',mean(gbest(:,end)),std(gbest(:,end)),max(gbest(:,end)), min(gbest(:,end)), median(gbest(:,end)));
file_name=sprintf('Mean\\KCACIL_%s_%s.txt',int2str(func),int2str(D));
save(file_name, 'Mean', '-ascii');
file_name=sprintf('Std\\KCACIL_%s_%s.txt',int2str(func),int2str(D));
save(file_name, 'Std', '-ascii');
file_name=sprintf('Max\\KCACIL_%s_%s.txt',int2str(func),int2str(D));
save(file_name, 'Max', '-ascii');
file_name=sprintf('Min\\KCACIL_%s_%s.txt',int2str(func),int2str(D));
save(file_name, 'Min', '-ascii');
file_name=sprintf('Median\\KCACIL_%s_%s.txt',int2str(func),int2str(D));
save(file_name, 'Median', '-ascii');
 end
% KCACIL(50,dim,DIM_RATE,low,up,MaxIter);
end

% 对立学习和混沌初始化
% function pop=GeneratePopulation(popsize,dim,low,up)
% % pop=ones(2*popsize,dim);
% pop1=ones(popsize,dim);
% pop2=ones(popsize,dim);
% for i=1:popsize
%     for j=1:dim
%         ch=rand;
%         for k=1:300
%             ch=sin(pi*ch);
%         end
%         pop1(i,j)=ch*(up(j)-low(j))+low(j);
%         pop2(i,j)=up(j)+low(j)-pop1(i,j);
%     end
% end
% pop=[pop1;pop1];
% return


