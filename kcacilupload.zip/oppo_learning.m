function pop=oppo_learning(N,func,tao,Q,dim,low,up,worstx)
% pop=ones(2*popsize,dim);
   pop1=ones(N,dim);
   pop2=ones(N,dim);
   pop11=ones(N,dim);
   pop3=ones(N,dim);
   NN = floor(N * tao);
   [~,index]=sort(Q);
   i=1:NN;
   Sup_Pop(i,:) = pop(index(i),:);
%    fitness_sup = FitnessValue(1:NN,:);
      pop1=low+up-pop1;
      pop11=(low+up)/2;
      pop2=rand([pop11,pop1],N,dim);
      pop3=rand([pop2,pop11],N,dim);
      pop3=BoundaryControl(pop3,low,up);
      fitnesspop3=ObjFun(pop3,func);
      if fitnesspop3<fitnessP
          P=pop3;
      else
          P=P;
      end
