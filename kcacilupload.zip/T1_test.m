clear
clc

fhd = @cec17_func;
D = 30;
pop_size = 100;
Xmin = -100;Xmax = 100;
tic
for i = 1:2000
    X = Xmin + rand(D,pop_size) * (Xmax - Xmin);
    fitness = fhd(X,18);
end
toc