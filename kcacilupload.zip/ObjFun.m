function fun = ObjFun(x,func)
fun=cec14_func(x',func);
return
% function fun=ObjFun(x)
% D=size(x,2);
% fun=0;
% for i=1:D
%     for j=1:i
%         fun=fun+(x(j)')^2;
%     end
% end