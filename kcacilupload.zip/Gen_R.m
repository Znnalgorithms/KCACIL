function R = Gen_R(NP_Size,N)


R(1,:)=1:NP_Size;

for i=2:N+1
    
    R(i,:) = ceil(rand(NP_Size,1) * NP_Size);
    
    flag=0;
    while flag ~= 1
        pos = (R(i,:) == R(1,:));
        for w=2:i-1
            pos=or(pos,(R(i,:) == R(w,:)));
        end
        if sum(pos) == 0
            flag=1;
        else
            R(i,pos)= floor(rand(sum(pos),1 ) * NP_Size) + 1;
        end
    end
end

R=R';

end
