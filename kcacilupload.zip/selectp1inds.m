function [p] = selectp1inds(N, P,fitnessP1,fitnessP2,fitnessP3)   

p1=(1-(sum(fitnessP1))/sum(fitnessP1+fitnessP2+fitnessP3))^2;
  NN1 = round(N * p1);
  [~,idx1]=sort(fitnessP1);
  i=1:NN1;
  pbest1 = P(idx1(i),:);
 

