%==========MPEDE==========%
clc;
clear all;

format long;
format compact;

val_2_reach = 10^(-30);
RecordFEsFactor = ...
    [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
    0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
progress = numel(RecordFEsFactor);

fhd=@cec14_func;
runs = 25;
for problem_size = [10,30,50,100]
    
    max_nfes = 10000 * problem_size;
    rand('seed', sum(100 * clock));
    lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
    
    fprintf('Running Algorithm\n')
    
    for func = 1: 30
        optimum = func * 100.0;
        
        %% ��¼��ѽ��
        outcome = [];
        fprintf('\n-------------------------------------------------------\n')
        fprintf('Function = %d, Dimension size = %d\n', func, problem_size)
        allerrorvals = zeros(progress, runs);
        
        for run_id = 1 : runs
            %tic
            run_funcvals = [];
            %%  parameter settings
            xxleastSelectionPro = 0.2;
            leastSelectionPro = xxleastSelectionPro;
            Afactor = 1;
            memory_size = 6;
            xxpopsize = 250;
            CRm2 = 0.5;
            Fm2 = 0.5;
            CRm3 = 0.5;
            Fm3 = 0.5;
            c = 1/10;
            n = problem_size;
            D = n;
            pj = 0.11;
            CRm = 0.5;
            Fm = 0.5;
            goodCR = [];
            goodF = [];
            nfes = 0;
            FESj = 0;
            gen = 0;
            arrayGbestChange = [0,0,0];
            arrayGbestChangeRate = [0,0,0];
            genForChange = 20;
            indexBestLN = 1;
            numViaLN = [0,0,0];
            consumedFES = [0,0,0];
            
            %% ������ʼ��Ⱥ
            mixPop = repmat(lu(1, :), xxpopsize, 1) + rand(xxpopsize, problem_size) .* (repmat(lu(2, :) - lu(1, :), xxpopsize, 1));
            %             pop = popold;
            mixVal = feval(fhd,mixPop',func);
            mixVal = mixVal';
            
            bsf_fit_var = 1e+30;
            bsf_index = 0;
            bsf_solution = zeros(1, problem_size);
            
            %%%%%%%%%%%%%%%%%%%%%%%% for out
            for i = 1 : xxpopsize
                %nfes = nfes + 1;
                
                if mixVal(i) < bsf_fit_var
                    bsf_fit_var = mixVal(i);
                    bsf_solution = mixPop(i, :);
                    bsf_index = i;
                end
                
                %                 if nfes > max_nfes
                %                     break;
                %                 end
            end
            %%%%%%%%%%%%%%%%%%%%%%%% for out
            run_funcvals = [run_funcvals;ones(xxpopsize,1)*bsf_fit_var];
            
            archive.NP = Afactor * xxpopsize; % the maximum size of the archive
            archive.pop = zeros(0, problem_size); % the solutions stored in te archive
            archive.funvalues = zeros(0, 1); % the function value of the archived solutions
            
            
            %% main loop  ��ѭ��
            while nfes < max_nfes
                gen = gen +1;
                if mod(gen,genForChange) == 0
                    arrayGbestChangeRate(1) = arrayGbestChange(1)/consumedFES(1);% �ݴ�ѡ�����
                    arrayGbestChangeRate(2) = arrayGbestChange(2)/consumedFES(2);
                    arrayGbestChangeRate(3) = arrayGbestChange(3)/consumedFES(3);
                    [~,indexBestLN]=max(arrayGbestChangeRate);
                    if sum(arrayGbestChangeRate == arrayGbestChangeRate(1)) == 3
                        indexBestLN = randi([1,3],1);% 1,2,3���ѡһ��
                    end
                    arrayGbestChange = [0,0,0];% ����
                    arrayGbestChangeRate =  [0,0,0];% ����
                    consumedFES = [0,0,0];% ����
                end
                permutation = randperm(xxpopsize);
                if indexBestLN == 1
                    arrayThird= permutation(1:leastSelectionPro*xxpopsize);
                    arraySecond = permutation(leastSelectionPro*xxpopsize+1: 2*leastSelectionPro*xxpopsize);
                    arrayFirst = permutation(2*leastSelectionPro*xxpopsize+1:end);
                    numViaLN(1) = numViaLN(1) + 1;
                elseif indexBestLN == 2
                    arrayThird = permutation(1:leastSelectionPro*xxpopsize);
                    arrayFirst = permutation(leastSelectionPro*xxpopsize+1: 2*leastSelectionPro*xxpopsize);
                    arraySecond  = permutation(2*leastSelectionPro*xxpopsize+1:end);
                    numViaLN(2) = numViaLN(2) + 1;
                elseif indexBestLN == 3
                    arrayFirst = permutation(1:leastSelectionPro*xxpopsize);
                    arraySecond = permutation(leastSelectionPro*xxpopsize+1: 2*leastSelectionPro*xxpopsize);
                    arrayThird  = permutation(2*leastSelectionPro*xxpopsize+1:end);
                    numViaLN(3) = numViaLN(3) + 1;
                end
                consumedFES = consumedFES + [length(arrayFirst),length(arraySecond),length(arrayThird)];
                %%  %% ===========================mutation 1=====================================%%%%
                if ~isempty(arrayFirst)
                    pop1 = mixPop(arrayFirst,:); % the old population becomes the current population
                    valParents1 = mixVal(arrayFirst);
                    %                     valParents1 = valParents1';
                    popsize = length(arrayFirst);
                    [~,I1]=sort(mixVal, 'ascend');
                    [~,I2]=sort(valParents1, 'descend');
                    pop1(I2(1),:) = mixPop(I1(1),:);% �滻
                    valParents1(I2(1)) = mixVal(I1(1));
                    prevalParents1 = valParents1;
                    
                    if FESj > 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
                        CRm = (1 - c) * CRm + c * mean(goodCR);
                        Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF); % Lehmer mean
                    end
                    % Generate CR according to a normal distribution with mean CRm, and std 0.1
                    % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
                    [Fj, CRj] = randFCR(popsize, CRm, 0.1, Fm, 0.1);
                    r0 = [1 : popsize];
                    popAll = [pop1; archive.pop];
                    [r1, r2] = gnR1R2(popsize, size(popAll, 1), r0);
                    % Find the p-best solutions
                    [~, indBest] = sort(valParents1, 'ascend');
                    pNP = max(round(pj * popsize), 2); % choose at least two best solutions
                    randindex = ceil(rand(1, popsize) * pNP); % select from [1, 2, 3, ..., pNP]
                    randindex = max(1, randindex); % to avoid the problem that rand = 0 and thus ceil(rand) = 0
                    pbest = pop1(indBest(randindex), :); % randomly choose one of the top 100p% solutions
                    % == == == == == == == == == == == == == == == Mutation == == == == == == == == == == == == ==
                    vi = pop1 + Fj(:, ones(1, n)) .* (pbest - pop1 + pop1(r1, :) - popAll(r2, :));
                    vi = boundConstraint(vi, pop1, lu);
                    
                    % == == == == = Crossover == == == == =
                    mask = rand(popsize, n) > CRj(:, ones(1, n)); % mask is used to indicate which elements of ui comes from the parent
                    rows = (1 : popsize)'; cols = floor(rand(popsize, 1) * n)+1; % choose one position where the element of ui doesn't come from the parent
                    jrand = sub2ind([popsize n], rows, cols); mask(jrand) = false;
                    ui = vi; ui(mask) = pop1(mask);
                    
                    valOffspring1 = feval(fhd,ui(:,1:problem_size)',func);
                    % valOffspring1 = ObjFun(ui,func);% ������Ӧ��ֵ
                    valOffspring1 = valOffspring1';
                    bsf_index = 0;
                    bsf_solution = zeros(1, problem_size);
                    %% for out
                    for i = 1 : popsize
                        nfes = nfes + 1;
                        if valOffspring1(i) < bsf_fit_var
                            bsf_fit_var = valOffspring1(i);
                            bsf_solution = ui(i, :);
                            bsf_index = i;
                        end
                        if nfes > max_nfes
                            break;
                        end
                    end
                    %%% for out
                    run_funcvals = [run_funcvals;ones(popsize,1)*bsf_fit_var];
                    FESj = FESj + popsize;
                    %nfes = nfes + popsize;
                    
                    % I == 1: the parent is better; I == 2: the offspring is better
                    [valParents1, I] = min([valParents1, valOffspring1], [], 2);% ���õĽ�ŵ�valParents1��
                    popold1 = pop1;
                    archive = updateArchive(archive, popold1(I == 2, :), valParents1(I == 2));
                    popold1(I == 2, :) = ui(I == 2, :);
                    goodCR = CRj(I == 2);
                    goodF = Fj(I == 2);
                    %                     if min(valParents1)< overallBestVal
                    %                         overallBestVal = min(valParents1);
                    %                     end
                    arrayGbestChange(1) = arrayGbestChange(1) + sum(prevalParents1- valParents1);
                    if prevalParents1(I2(1)) == valParents1(I2(1))             % ����
                        popold1(I2(1),:) =  mixPop(arrayFirst(I2(1)),:);
                        valParents1(I2(1)) = mixVal(arrayFirst(I2(1)));
                    end
                    mixPop(arrayFirst,:) = popold1;
                    mixVal(arrayFirst) = valParents1;
                end
                %% ===========================mutation 2=====================================%%%%
                if ~isempty(arraySecond)
                    pop2 = mixPop(arraySecond,:); % the old population becomes the current population
                    valParents2 = mixVal(arraySecond);
                    %                     valParents2 = valParents2';
                    popsize2 = length(arraySecond);
                    [~,I1]=sort(mixVal, 'ascend');
                    [~,I2]=sort(valParents2, 'descend');
                    pop2(I2(1),:) = mixPop(I1(1),:);
                    valParents2(I2(1)) = mixVal(I1(1));
                    prevalParents2 = valParents2;
                    
                    if gen > 1 && ~isempty(goodCR2) && sum(goodF2) > 0 % If goodF and goodCR are empty, pause the update
                        CRm2 = (1 - c) * CRm2 + c * mean(goodCR2);
                        Fm2 = (1 - c) * Fm2 + c * sum(goodF2 .^ 2) / sum(goodF2); % Lehmer mean
                    end
                    % Generate CR according to a normal distribution with mean CRm, and std 0.1
                    % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
                    [F2, CR2] = randFCR(popsize2, CRm2, 0.1, Fm2, 0.1);
                    
                    %%
                    rot = (0:1:popsize2-1);
                    ind = randperm(2);
                    a1 = randperm(popsize2);             % shuffle locations of vectors
                    rt = rem(rot+ind(1),popsize2);        % rotate indices by ind(1) positions
                    a2  = a1(rt+1);                 % rotate vector locations
                    rt = rem(rot+ind(2),popsize2);
                    a3  = a2(rt+1);
                    pm1 = pop2(a1,:);             % shuffled population 1
                    pm2 = pop2(a2,:);             % shuffled population 2
                    pm3 = pop2(a3,:);             % shuffled population 3
                    %%
                    vi =pop2 + repmat(rand(popsize2,1),1,D) .* (pm1 - pop2) + F2(:, ones(1, D)) .* (pm2 - pm3);
                    vi = boundConstraint(vi, pop2, lu);
                    ui = vi;
                    
                    valOffspring2 = feval(fhd,ui(:,1:problem_size)',func);
                    %valOffspring2 = ObjFun(ui,func);
                    valOffspring2 = valOffspring2';
                    bsf_index = 0;
                    bsf_solution = zeros(1, problem_size);
                    %% for out
                    for i = 1 : popsize2
                        nfes = nfes + 1;
                        if valOffspring2(i) < bsf_fit_var
                            bsf_fit_var = valOffspring2(i);
                            bsf_solution = ui(i, :);
                            bsf_index = i;
                        end
                        if nfes > max_nfes
                            break;
                        end
                    end
                    %%% for out
                    run_funcvals = [run_funcvals;ones(popsize2,1)*bsf_fit_var];
                    %FES = FES + popsize2;
                    % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
                    % I == 1: the parent is better; I == 2: the offspring is better
                    [valParents2, I] = min([valParents2, valOffspring2], [], 2);
                    popold2 = pop2;
                    %             archive = updateArchive(archive, popold(I == 2, :), valParents2(I == 2));
                    popold2(I == 2, :) = ui(I == 2, :);
                    goodCR2 = CR2(I == 2);
                    goodF2 = F2(I == 2);
                    
                    arrayGbestChange(2) = arrayGbestChange(2) + sum(prevalParents2- valParents2);
                    if prevalParents2(I2(1)) == valParents2(I2(1))               % ����
                        popold2(I2(1),:) =  mixPop(arraySecond(I2(1)),:);
                        valParents2(I2(1)) = mixVal(arraySecond(I2(1)));
                    end
                    mixPop(arraySecond,:) = popold2;
                    mixVal(arraySecond) = valParents2;
                end
                %% ===========================mutation 3 =====================================%%%%
                if ~isempty(arrayThird)
                    pop3 = mixPop(arrayThird,:); % the old population becomes the current population
                    valParents3 = mixVal(arrayThird);
                    %valParents3 = valParents3';
                    popsize3 = length(arrayThird);
                    [~,I1]=sort(mixVal, 'ascend');
                    [~,I2]=sort(valParents3, 'descend');
                    pop3(I2(1),:) = mixPop(I1(1),:);
                    valParents3(I2(1)) = mixVal(I1(1));
                    prevalParents3 = valParents3;
                    if gen > 1 && ~isempty(goodCR3) && sum(goodF3) > 0 % If goodF and goodCR are empty, pause the update
                        CRm3 = (1 - c) * CRm3 + c * mean(goodCR3);
                        Fm3 = (1 - c) * Fm3 + c * sum(goodF3 .^ 2) / sum(goodF3); % Lehmer mean
                    end
                    % Generate CR according to a normal distribution with mean CRm, and std 0.1
                    % Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
                    [F3, CR3] = randFCR(popsize3, CRm3, 0.1, Fm3, 0.1);
                    %%
                    rot = (0:1:popsize3-1);
                    ind = randperm(2);
                    a1  = randperm(popsize3);             % shuffle locations of vectors
                    rt = rem(rot+ind(1),popsize3);        % rotate indices by ind(1) positions
                    a2  = a1(rt+1);                 % rotate vector locations
                    rt = rem(rot+ind(2),popsize3);
                    a3  = a2(rt+1);
                    pm1 = pop3(a1,:);             % shuffled population 1
                    pm2 = pop3(a2,:);             % shuffled population 2
                    pm3 = pop3(a3,:);             % shuffled population 3
                    %%
                    vi =pm1 + F3(:, ones(1, D)) .* (pm2 - pm3); %repmat(rand(popsize3,1),1,D) .* (pm1 - pop3)
                    vi = boundConstraint(vi, pop3, lu);
                    mask = rand(popsize3, n) > CR3(:, ones(1, n)); % mask is used to indicate which elements of ui comes from the parent
                    rows = (1 : popsize3)'; cols = floor(rand(popsize3, 1) * n)+1; % choose one position where the element of ui doesn't come from the parent
                    jrand = sub2ind([popsize3 n], rows, cols); mask(jrand) = false;
                    ui = vi; ui(mask) = pop3(mask);
                    
                    valOffspring3 = feval(fhd,ui(:,1:problem_size)',func);
                    %valOffspring3 = ObjFun(ui,func);
                    valOffspring3 = valOffspring3';
                    bsf_index = 0;
                    bsf_solution = zeros(1, problem_size);
                    %% for out
                    for i = 1 : popsize3
                        nfes = nfes + 1;
                        if valOffspring3(i) < bsf_fit_var
                            bsf_fit_var = valOffspring3(i);
                            bsf_solution = ui(i, :);
                            bsf_index = i;
                        end
                        if nfes > max_nfes
                            break;
                        end
                    end
                    %%% for out
                    run_funcvals = [run_funcvals;ones(popsize3,1)*bsf_fit_var];
                    %FES = FES + popsize3;
                    % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
                    % I == 1: the parent is better; I == 2: the offspring is better
                    [valParents3, I] = min([valParents3, valOffspring3], [], 2);
                    popold3 = pop3;
                    %             archive = updateArchive(archive, popold(I == 2, :), valParents2(I == 2));
                    popold3(I == 2, :) = ui(I == 2, :);
                    goodCR3 = CR3(I == 2);
                    goodF3 = F3(I == 2);
                    arrayGbestChange(3) = arrayGbestChange(3) + sum(prevalParents3- valParents3);
                    
                    if prevalParents3(I2(1)) == valParents3(I2(1))              % ����
                        popold3(I2(1),:) =  mixPop(arrayThird(I2(1)),:);
                        valParents3(I2(1)) = mixVal(arrayThird(I2(1)));
                    end
                    mixPop(arrayThird,:) = popold3;
                    mixVal(arrayThird) = valParents3;
                end
            end% nfes
            
            %% Violation Checking
            if(max(bsf_solution)>100)
                fprintf('%d th run, Above Max\n', run_id)
            end
            
            if(min(bsf_solution)<-100)
                fprintf('%d th run, Below Min\n', run_id)
            end
            
            if(~isreal(bsf_solution))
                fprintf('%d th run, Complix\n', run_id)
            end
            
            bsf_error_val = abs(bsf_fit_var - optimum);
            if bsf_error_val < val_2_reach
                bsf_error_val = 0;
            end
            
            if(sum(isnan(bsf_solution))>0)
                fprintf('%d th run, NaN\n', run_id)
            end
            %% ���
            fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , bsf_error_val)
            outcome = [outcome bsf_error_val];
            
            %% From Noor Code ( print files )
            errorVals= [];
            for w = 1 : progress
                bestold = run_funcvals(RecordFEsFactor(w) * max_nfes) - optimum;
                if abs(bestold)>1e-30
                    errorVals(w)= abs(bestold);
                else
                    bestold=0;
                    errorVals(w)= bestold;
                end
            end
            allerrorvals(:, run_id) = errorVals;
            %toc
        end% end 1 run
        
        fprintf('\n')
        fprintf('min error value = %1.8e, max = %1.8e, median = %1.8e, mean = %1.2e, std = %1.2e\n', min(outcome), max(outcome), median(outcome), mean(outcome), std(outcome))
        Mean=mean( allerrorvals(end,:));
        Std=std( allerrorvals(end,:));
        Max=max( allerrorvals(end,:));
        Min=min( allerrorvals(end,:));
        Median=median( allerrorvals(end,:));
        fprintf('Mean =%g Std=%g max =%g min=%g median =%g\n',mean( allerrorvals(end,:)),std( allerrorvals(end,:)),max( allerrorvals(end,:)), min( allerrorvals(end,:)), median( allerrorvals(end,:)));
        file_name=sprintf('Mean\\MPEDE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Mean', '-ascii');
        file_name=sprintf('Std\\MPEDE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Std', '-ascii');
        file_name=sprintf('Max\\MPEDE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Max', '-ascii');
        file_name=sprintf('Min\\MPEDE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Min', '-ascii');
        file_name=sprintf('Median\\MPEDE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Median', '-ascii');
        
        file_name=sprintf('Results\\MPEDE14_Problem#%s_problemSize#%s',int2str(func),int2str(problem_size));
        save(file_name,'outcome', 'allerrorvals');
        
        
        file_name=sprintf('Results\\MPEDE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'allerrorvals', '-ascii');
    end% end 1 func
end