 function inditempX = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy)
%����������������
%k=20;
% S=1-0.2*exp(1-T/(T-t+1)); 
S=exp(1-T/(T-t+1));
%stepSize = ones(1,D);
map=ones(1,D);
if rand<rand 
    u=randperm(D);
    map(1,u(1:ceil(rand*D)))=0;   
else    
    map(1,randi(D))=0;     
end
F= 1 * randn;

for i = 1:N
    switch mutationStrategy        
        case 1                
            cluster1 = ceil(rand()*M); %ceil:���ش��ڻ��ߵ���ָ������ʽ����С����
            indi1 = numberInClusterPre(cluster1,1) + ceil(rand()*numberInCluster(cluster1,1));
            Xi1 = xSorted(indi1,:);
            cluster2 = ceil(rand()*M);
            indi2 = numberInClusterPre(cluster2,1) + ceil(rand()*numberInCluster(cluster2,1));
            Xi2 = xSorted(indi2,:);
            xElite = xElitist(ceil(rand()*3),:);
            inditempX(1,:) = xElite + S*(Xi1-Xi2); 
                        
        case 2             
            r1 = rand();
        for j = 1:M%���ѡ��һ������ΪPi�Ĵ�
            if r1 < xProb(j,1)
                inditemp1 = numberInClusterPre(j,1) + ceil(rand()*numberInCluster(j,1));
                inditemp2 = numberInClusterPre(j,1) + ceil(rand()*numberInCluster(j,1));
                Xp1 = xSorted(inditemp1,:);
                Xp2 = xSorted(inditemp2,:);
                Xp_center = centers(j,:);
                inditempX(1,:) = Xp_center + S*(Xp1-Xp2);
                break;%������ǰѭ��
            end
        end                 
        case 3                        
            r1 = rand();
            for j = 1:M%���ѡ��һ������ΪPi�Ĵ�
                if r1 < xProb(j,1)
                    inditemp1 = numberInClusterPre(j,1) + ceil(rand()*numberInCluster(j,1));
                    inditemp2 = numberInClusterPre(j,1) + ceil(rand()*numberInCluster(j,1));
                    Xgbest = xElitist(1,:);
                    Xi = x(i,:);
                    Xb1 = xSorted(inditemp1,:);
                    Xb2 = xSorted(inditemp2,:);
                    %S3 = 0.9;
                    inditempX(1,:) = Xi + S * (Xgbest - Xi) + S * (Xb1 - Xb2);
                    break;%������ǰѭ��
                end
            end
        case 4
            a=1;
            b=N;
            dx=randperm(b-a+1);
            r1=dx(1);
            r2=dx(2);
            r3=dx(3);
            if r1==i
                r1=dx(4);
            elseif r2==i
                r2=dx(4);
            elseif r3==i
                r3=dx(4);
            end
            inditempX(1,:) = x(i,:)+(map*F).*(oldx(r1,:)-x(i,:))+(map.*F).*(oldx(r2,:)-oldx(r3,:));             
    end

end


