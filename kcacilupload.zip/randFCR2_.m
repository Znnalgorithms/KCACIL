function [F2,CR2,u2,fitnessU2] = randFCR2(N,dim, CRm, CRsigma,Fm, Fsigma,t,G,fitnessP1,fitnessP2,fitnessP3)   
cc=0.9-0.9*10^(-5)*t/G;
w=deltafitnessP2/sum(deltafitnessP1+deltafitnessP2+deltafitnessP3);
meanL(w*F2)=sum(w*F2^2)/sum(w*F2);
CRm=(1-cc)*CRm+cc*mean(w*CR2);

CR2 = min(1, max(0, CR2));              
%%%
Fm=(1-cc)*Fm+cc*meanL(w*F2);

% F = randCauchy(NP, 1, Fm, Fsigma);    
F2 = min(1, F2);
pos = find(F2 <= 0);
while ~ isempty(pos)
%     F(pos) = randCauchy(length(pos), 1, Fm, Fsigma);
    F2(P) = randCauchy(length(pos),1,Fm,Fsigma); 
    F2 = min(1, F2);                      % truncation
    pos = find(F2 <= 0);
end
 r0 = (1 : N);
               
 [r1, r2] = gnR1R2(N, size(P2, 1), r0);
%  b = F1(:, ones(1, problem_size));
                vi = P2 + F2 .* (pbest2 - P2 + P2(r1, :) - P2(r2, :));
                vi = boundConstraint2(vi, P2, lu);
                %% 
                mask = rand(N, dim) > CR2(:, ones(1, dim)); 
                rows = (1 : N)';
                cols = floor(rand(N, 1) * dim)+1;                
                jrand = sub2ind([N dim], rows, cols);           
                mask(jrand) = false;
                u2 = vi;
                u2(mask) = P2(mask);
                %% 
                % I == 1: the parent is better; I == 2: the offspring is better
%                 fitnessP=ObjFun(P,func);
                fitnessU2 = ObjFun(u2(:,1:dim)',func);
                fitnessU2 = fitnessU2';
                
                %% 
% %                 archive = updateArchive2(archive,P1(I == 2, :), U1(I == 2));
% %                 P1(I == 2, :) = ui(I == 2, :);
% %                 goodCR = CR(I == 2);
% %                 goodF = F(I == 2);
                %%%%%%%%%%%%%%%%%%%%%% for out
                
                    if u2 < bsf_fit_var
                        bsf_fit_var = u2;
                        bsf_solution = P2(i, :);
                        bsf_index = i;
                    end
                    K=sum(fitnessP2)/N;
                    KK=sum(fitnessU2)/N;
                    if KK<K
                        CR2=cc*CR1+(1-cc)*CR2;
                        F2=cc*F2+(1-cc)*F2;
                    else
                        F2 = randCauchy(N, 1, Fm, Fsigma); 
                       
                        CR2 = normrnd(CRm,CRsigma,[NP,1]);   
                    end
% Cauchy distribution: cauchypdf = @(x, mu, delta) 1/pi*delta./((x-mu).^2+delta^2)
%% 
% function result = randCauchy(m, n, mu, delta)
% result = mu + delta * tan(pi * (rand(m, n) - 0.5));
% %result = tan(pi * (rand(m, n) - 0.5));
