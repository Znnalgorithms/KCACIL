function [p] = selectp3inds(N, P,fitnessP1,fitnessP2,fitnessP3,Q)   
p3=(1-(sum(fitnessP3))/sum(fitnessP1+fitnessP2+fitnessP3))^2;

[~,idx3]=sort(Q);
NN3=round(p3*N);
i=1:NN3;
pbest3(i,:)=P3(idx3(i),:);


