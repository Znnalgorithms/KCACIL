%==========JADE==========%

clear all;
clc;
format long;
format compact;

val_2_reach = 10^(-30);

RecordFEsFactor = ...
    [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
    0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
progress = numel(RecordFEsFactor);

fhd=@cec14_func;

runs = 10;
for problem_size = [10,30,50,100]
    
    max_nfes = 10000 * problem_size;% ������۴���
    rand('seed', sum(100 * clock));
    lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
    
    fprintf('Running algorithm\n')
    
    for func = 1:30
        optimum = func * 100.0;
        
        %% ��¼��ѽ��
        outcome = [];
        fprintf('\n-------------------------------------------------------\n')
        fprintf('Function = %d, Dimension size = %d\n', func, problem_size)
        allerrorvals = zeros(progress, runs);
        
        for run_id = 1 : runs
            %tic
            nfes = 0;
            run_funcvals = [];
            
            %% ��������
            popsize = 100;
            c = 0.1;
            p = 0.1;% ǰp%�ĸ���
            CRm = 0.5;
            CRsigma = 0.1;
            Fm = 0.5;
            Fsigma = 0.1;
            Afactor = 1;
            goodCR = [];
            goodF = [];
            %% �浵
            archive.NP = Afactor * popsize;% �浵���Ĵ�С
            archive.pop = zeros(0, problem_size);% �洢������
            archive.funvalues = zeros(0, 1);% �洢��Ӧ����Ӧ��ֵ
            %% ������ʼ��Ⱥ
            popold = repmat(lu(1, :), popsize, 1) + rand(popsize, problem_size) .* (repmat(lu(2, :) - lu(1, :), popsize, 1));
            
            nfes = 0;
            bsf_fit_var = 1e+30;
            
            %% ��ѭ��
            while nfes < max_nfes
                pop = popold; % the old population becomes the current population
                if nfes > 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
                    CRm = (1 - c) * CRm + c * mean(goodCR);
                    Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF);% Lehmer mean
                end
                %% ������Ӧ��ֵ
                valParents = feval(fhd,pop(:,1:problem_size)',func);
                [valBest, indBest] = sort(valParents, 'ascend');% ����
                valParents = valParents';
                bsf_index = 0;
                bsf_solution = zeros(1, problem_size);
                %% for out
                for i = 1 : popsize
                    nfes = nfes + 1;
                    if valParents(i) < bsf_fit_var
                        bsf_fit_var = valParents(i);
                        bsf_solution = pop(i, :);
                        bsf_index = i;
                    end
                    if nfes > max_nfes
                        break;
                    end
                end
                %%% for out
                run_funcvals = [run_funcvals;ones(popsize,1)*bsf_fit_var];
                
                %% Generate CR according to a normal distribution with mean CRm, and std 0.1
                ... Generate F according to a cauchy distribution with location parameter Fm, and scale parameter 0.1
                    [F, CR] = randFCR2(popsize, CRm, CRsigma, Fm, Fsigma);
                
                r0 = (1 : popsize);% 1 2 ...100
                popAll = [pop;archive.pop];
                %% ������ͬ�Ľ�
                [r1, r2] = gnR1R22(popsize, size(popAll, 1), r0); % 1 ����������2��������
                
                %% Find the p-best solutions
                pNP = max(round(p * popsize), 2);                          % choose at least two best solutions
                randindex = ceil(rand(1, popsize) * pNP);                  % select from [1, 2, 3, ..., pNP]
                randindex = max(1, randindex);                             % to avoid the problem that rand = 0 and thus ceil(rand) = 0
                a = indBest(randindex);
                pbest = pop(indBest(randindex), :);                        % randomly choose one of the top 100p% solutions
                %% Mutation (��ѭ�����)
                b = F(:, ones(1, problem_size));
                vi = pop + b .* (pbest - pop + pop(r1, :) - popAll(r2, :));
                vi = boundConstraint2(vi, pop, lu);%�߽紦��
                %% Crossover
                mask = rand(popsize, problem_size) > CR(:, ones(1, problem_size)); % mask is used to indicate which elements of ui comes from the parent
                rows = (1 : popsize)';
                cols = floor(rand(popsize, 1) * problem_size)+1;                % choose one position where the element of ui doesn't come from the parent
                jrand = sub2ind([popsize problem_size], rows, cols);            % �Ծ��������ż����ĺ��������±�ת��Ϊ������������rows�У���cols�е���������
                mask(jrand) = false;
                ui = vi;
                ui(mask) = pop(mask);% ÿһ�����ÿһά����־λΪ1�ĸ�Ԫ�����Ը���
                %% Selection
                % I == 1: the parent is better; I == 2: the offspring is better
                valOffspring = feval(fhd,ui(:,1:problem_size)',func);
                valOffspring = valOffspring';
                [valParents, I] = min([valParents, valOffspring], [], 2);% 2�������е���Сֵ
                 popold = pop;
                %% ���µ�����
                archive = updateArchive2(archive, popold(I == 2, :), valParents(I == 2));% popold(I == 2, :)Ϊ�����нϲ�Ľ⣬��������������С��������޳�һЩ
                popold(I == 2, :) = ui(I == 2, :);
                goodCR = CR(I == 2);
                goodF = F(I == 2);
                %%%%%%%%%%%%%%%%%%%%%% for out
                for i = 1 : popsize
                    nfes = nfes + 1;
                    if valParents(i) < bsf_fit_var
                        bsf_fit_var = valParents(i);
                        bsf_solution = popold(i, :);
                        bsf_index = i;
                    end
                    if nfes > max_nfes
                        break;
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%% for out
                run_funcvals = [run_funcvals;ones(popsize,1)*bsf_fit_var];       
                
            end% nfes
            %% Violation Checking
            if(max(bsf_solution)>100)
                fprintf('%d th run, Above Max\n', run_id)
            end
            
            if(min(bsf_solution)<-100)
                fprintf('%d th run, Below Min\n', run_id)
            end
            
            if(~isreal(bsf_solution))
                fprintf('%d th run, Complix\n', run_id)
            end
            
            bsf_error_val = abs(bsf_fit_var - optimum);
            if bsf_error_val < val_2_reach
                bsf_error_val = 0;
            end
            
            if(sum(isnan(bsf_solution))>0)
                fprintf('%d th run, NaN\n', run_id)
            end
            %% ���
            fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , bsf_error_val)
            outcome = [outcome bsf_error_val];
            
            %% From Noor Code ( print files )
            errorVals= [];
            for w = 1 : progress
                bestold = run_funcvals(RecordFEsFactor(w) * max_nfes) - optimum;
                if abs(bestold)>1e-30
                    errorVals(w)= abs(bestold);
                else
                    bestold=0;
                    errorVals(w)= bestold;
                end
            end
            allerrorvals(:, run_id) = errorVals;
            %toc
        end% end 1 run
        
        fprintf('\n')
        fprintf('min error value = %1.8e, max = %1.8e, median = %1.8e, mean = %1.2e, std = %1.2e\n', min(outcome), max(outcome), median(outcome), mean(outcome), std(outcome))
         Mean=mean(allerrorvals(end,:));
        Std=std(allerrorvals(end,:));
        Max=max(allerrorvals(end,:));
        Min=min(allerrorvals(end,:));
        Median=median(allerrorvals(end,:));
        fprintf('Mean =%g Std=%g max =%g min=%g median =%g\n',mean(allerrorvals(end,:)),std(allerrorvals(end,:)),max(allerrorvals(end,:)), min(allerrorvals(end,:)), median(allerrorvals(end,:)));
        file_name=sprintf('Mean\\JADE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Mean', '-ascii');
        file_name=sprintf('Std\\JADE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Std', '-ascii');
        file_name=sprintf('Max\\JADE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Max', '-ascii');
        file_name=sprintf('Min\\JADE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Min', '-ascii');
        file_name=sprintf('Median\\JADE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Median', '-ascii');
%         
        file_name=sprintf('Results\\JADE_CEC2017_Problem#%s_problemSize#%s',int2str(func),int2str(problem_size));
        save(file_name,'outcome', 'allerrorvals');
        
        
        file_name=sprintf('Results\\JADE_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'allerrorvals', '-ascii');
    end% end 1 func
end


