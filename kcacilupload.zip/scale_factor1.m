function F=scale_factor1  
     F=randn;
     
return
