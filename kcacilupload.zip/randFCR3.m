function [F3,CR3,u3,fitnessU3] = randFCR3(N,dim, CRm, CRsigma, Fm, Fsigma,t,G,fitnessP1,fitnessP2,fitnessP3)   
cc=0.9-0.9*10^(-5)*t/G;
w=deltafitnessP3/sum(deltafitnessP1+deltafitnessP2+deltafitnessP3);
meanL(w*F3)=sum(w*F3^2)/sum(w*F3);
CRm=(1-cc)*CRm+cc*meanL(w*CR3);
meanL(w*CR3)=sum(w*CR3^2)/sum(w*CR3);
CR3 = min(1, max(0, CR3));              
%%%
Fm=(1-cc)*Fm+cc*meanL(w*F3);

% F = randCauchy(NP, 1, Fm, Fsigma);    
F3 = min(1, F3);
pos = find(F3 <= 0);
while ~ isempty(pos)
%     F(pos) = randCauchy(length(pos), 1, Fm, Fsigma);
    F3(P) = randCauchy(length(pos),1,Fm,Fsigma); 
    F3 = min(1, F3);                      % truncation
    pos = find(F3 <= 0);
end
 r0 = (1 : N);
               
 [r1, r2, r3] = gnR1R2R3(N, size(P3, 1), r0);
%  b = F1(:, ones(1, problem_size));
                vi = P3 + F3 .* (pbest3 - P3(r1,:) + P3(r2, :) - P3(r3, :));
                vi = boundConstraint2(vi, P3, lu);
                %% 
                mask = rand(N, dim) > CR3(:, ones(1, dim)); 
                rows = (1 : N)';
                cols = floor(rand(N, 1) * dim)+1;                
                jrand = sub2ind([N dim], rows, cols);           
                mask(jrand) = false;
                u3 = vi;
                u3(mask) = P3(mask);
                %% 
                % I == 1: the parent is better; I == 2: the offspring is better
%                 fitnessP=ObjFun(P,func);
                fitnessU3 = ObjFun(u3(:,1:dim)',func);
                fitnessU3 = fitnessU3';
                
                %% 
% %                 archive = updateArchive2(archive,P1(I == 2, :), U1(I == 2));
% %                 P1(I == 2, :) = ui(I == 2, :);
% %                 goodCR = CR(I == 2);
% %                 goodF = F(I == 2);
                %%%%%%%%%%%%%%%%%%%%%% for out
                
                    if u3 < bsf_fit_var
                        bsf_fit_var = u3;
                        bsf_solution = P3(i, :);
                        bsf_index = i;
                    end
                    K=sum(fitnessP3)/N;
                    KK=sum(fitnessU3)/N;
                    if KK<K
                        CR3=cc*CR1+(1-cc)*CR3;
                        F3=cc*F3+(1-cc)*F3;
                    else
                        F3 = randCauchy(N, 1, Fm, Fsigma); 
                        CR3 = randCauchy(N, 1, CRm, CRsigma); 
                         
                    end
% Cauchy distribution: cauchypdf = @(x, mu, delta) 1/pi*delta./((x-mu).^2+delta^2)
%% 
% function result = randCauchy(m, n, mu, delta)
% result = mu + delta * tan(pi * (rand(m, n) - 0.5));
% %result = tan(pi * (rand(m, n) - 0.5));
