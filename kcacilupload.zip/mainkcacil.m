clc;
clear;
DIM_RATE=1;
for dim=[10]
  if dim==10
     G=100000;
%      MaxIter=3333;
  end
   if dim==30
     G=300000; 
%      MaxIter=10000;
   end
   if dim==50
     G=500000;
%      MaxIter=16666; 
   end
   if dim==100
     G=1000000;
%      MaxIter=33333;
   end
   low=-100*ones(1,dim);
   up=100*ones(1,dim);
    for func=[1]
        kcacill(50,dim,func,DIM_RATE,low,up,G);
    end
% HKBSA(50,dim,DIM_RATE,low,up,MaxIter);
end