% CMA-ES
clc;
clear all;

format long;
format compact;

val_2_reach = 10^(-200);
fhd=@cec14_func;
runs = 25;
RecordFEsFactor = ...
    [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
    0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
progress = numel(RecordFEsFactor);% ����14

for problem_size = [10,30,50,100]
    max_nfes = 10000 * problem_size;%������۴���
    rand('seed', sum(100 * clock));
    lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
%     lr = [-100 * ones(1,2);100 * ones(1,2)];
    fprintf('Running algorithm\n')
    
    for func = 1:30
        optimum = func * 100.0;
        %% Record the best results
        outcome = [];
        
        fprintf('\n-------------------------------------------------------\n')
        fprintf('Function = %d, Dimension size = %d\n', func, problem_size)
        
        allerrorvals = zeros(progress, runs);%��¼14����
        for run_id = 1 : runs
            arx = [];
            run_funcvals = [];
            nfes = 0;
            N = problem_size;
            %% ��������
            xmean = rand(N,1);    % objective variables initial point
            sigma = 0.5;          % coordinate wise standard deviation (step size) ���귽��ı�׼ƫ��
            % Strategy parameter setting: Selection
            lambda = 144+floor(3*log(N));  % population size, offspring number �Ӵ�����
            mu = lambda/2;               % number of parents/points for recombination ��������
            weights = log(mu+1/2)-log(1:mu)'; % muXone array for weighted recombination
            mu = floor(mu);
            weights = weights/sum(weights);     % normalize recombination weights array     ��׼��
            mueff=sum(weights)^2/sum(weights.^2); % variance-effectiveness of sum w_i x_i
            % Strategy parameter setting: Adaptation
            cc = (4 + mueff/N) / (N+4 + 2*mueff/N); % time constant for cumulation for C
            cs = (mueff+2) / (N+mueff+5);  % t-const for cumulation for sigma control
            c1 = 2 / ((N+1.3)^2+mueff);    % learning rate for rank-one update of C
            cmu = min(1-c1, 2 * (mueff-2+1/mueff) / ((N+2)^2+mueff));  % and for rank-mu update
            damps = 1 + 2*max(0, sqrt((mueff-1)/(N+1))-1) + cs; % damping for sigma
            % usually close to 1
            % Initialize dynamic (internal) strategy parameters and constants
            pc = zeros(N,1); ps = zeros(N,1);   % evolution paths for C and sigma
            B = eye(N,N);                       % B defines the coordinate system    ��λ��
            D = ones(N,1);                      % diagonal D defines the scaling
            C = B * diag(D.^2) * B';            % covariance matrix C
            invsqrtC = B * diag(D.^-1) * B';    % C^-1/2
            eigeneval = 0;                      % track update of B and D
            chiN=N^0.5*(1-1/(4*N)+1/(21*N^2));  % expectation of
            
            bsf_fit_var = 1e+30;
            bsf_index = 0;
            bsf_solution = zeros(1, problem_size);
            
            while nfes < max_nfes
%                 POP2 = repmat(lu(1,:),lambda,1) + rand(lambda,problem_size).* (repmat(lu(2,:)-lu(1,:),lambda,1));
                % Generate and evaluate lambda offspring
                for k=1:lambda,
                    arx(:,k) = xmean + sigma * B * (D .* randn(N,1)); % m + sig * Normal(0,C)  ������
                    %         arfitness(k) = feval(strfitnessfct, arx(:,k)); % objective function call ������Ӧ��ֵ
                end
                
%                 arx = boundConstraint2(arx',POP2,lu);
%                 arx = arx';
                
                %%%%%%%%%%%%%%%%%%%%%%%% for out
                arfitness = feval(fhd,arx,func);
                for i = 1 : lambda
                    nfes = nfes + 1;
                    if arfitness(i) < bsf_fit_var
                        bsf_fit_var = arfitness(i);
                        bsf_solution = arx(:, i);
                        bsf_index = i;
                    end
                    
                    if nfes > max_nfes;
                        break;
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%% for out
                
                run_funcvals = [run_funcvals;ones(lambda,1)*bsf_fit_var];
                
                % Sort by fitness and compute weighted mean into xmean
                [arfitness, arindex] = sort(arfitness);  % minimization
                xold = xmean;
                xmean = arx(:,arindex(1:mu)) * weights;  % recombination, new mean value
                
                % Cumulation: Update evolution paths
                ps = (1-cs) * ps + sqrt(cs*(2-cs)*mueff) * invsqrtC * (xmean-xold) / sigma;
                hsig = sum(ps.^2)/(1-(1-cs)^(2*nfes/lambda))/N < 2 + 4/(N+1);
                pc = (1-cc) * pc + hsig * sqrt(cc*(2-cc)*mueff) * (xmean-xold) / sigma;
                
                % Adapt covariance matrix C
                artmp = (1/sigma) * (arx(:,arindex(1:mu)) - repmat(xold,1,mu));  % mu difference vectors
                C = (1-c1-cmu) * C ...                   % regard old matrix
                    + c1 * (pc * pc' ...                % plus rank one update
                    + (1-hsig) * cc*(2-cc) * C) ... % minor correction if hsig==0
                    + cmu * artmp * diag(weights) * artmp'; % plus rank mu update
                
                % Adapt step size sigma
                sigma = sigma * exp((cs/damps)*(norm(ps)/chiN - 1));
                
                % Update B and D from C
                if nfes - eigeneval > lambda/(c1+cmu)/N/10  % to achieve O(N^2)
                    eigeneval = nfes;
                    C = triu(C) + triu(C,1)'; % enforce symmetry
                    [B,D] = eig(C);           % eigen decomposition, B==normalized eigenvectors �����ֽ�
                    D = sqrt(diag(D));        % D contains standard deviations now
                    invsqrtC = B * diag(D.^-1) * B';
                end
            end % end nfes
            %% Violation Checking
            %             if(max(bsf_solution)>100)
            %                 fprintf('%d th run, Above Max\n', run_id)
            %             end
            %
            %             if(min(bsf_solution)<-100)
            %                 fprintf('%d th run, Below Min\n', run_id)
            %             end
            %
            %             if(~isreal(bsf_solution))
            %                 fprintf('%d th run, Complix\n', run_id)
            %             end
            
            bsf_error_val = abs(bsf_fit_var - optimum);
            %             if bsf_error_val < val_2_reach
            %                 bsf_error_val = 0;
            %             end
            
            if(sum(isnan(bsf_solution))>0)
                fprintf('%d th run, NaN\n', run_id)
            end
            %% �������ʾ
            fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , bsf_error_val)
            outcome = [outcome bsf_error_val];
            
            %% From Noor Code ( print files )
            errorVals= [];
            for w = 1 : progress
                bestold = run_funcvals(RecordFEsFactor(w) * max_nfes) - optimum;
                if abs(bestold)>1e-200
                    errorVals(w)= abs(bestold);
                else
                    bestold=0;
                    errorVals(w)= bestold;
                end
            end
            allerrorvals(:, run_id) = errorVals;
        end % end 1 run
        fprintf('\n')
        fprintf('min error value = %1.8e, max = %1.8e, median = %1.8e, mean = %1.2e, std = %1.2e\n', min(outcome), max(outcome), median(outcome), mean(outcome), std(outcome))
         Mean=mean(allerrorvals(end,:));
        Std=std(allerrorvals(end,:));
        Max=max(allerrorvals(end,:));
        Min=min(allerrorvals(end,:));
        Median=median(allerrorvals(end,:));
        fprintf('Mean =%g Std=%g max =%g min=%g median =%g\n',mean(allerrorvals(end,:)),std(allerrorvals(end,:)),max(allerrorvals(end,:)), min(allerrorvals(end,:)), median(allerrorvals(end,:)));
        file_name=sprintf('Mean\\CMAES_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Mean', '-ascii');
        file_name=sprintf('Std\\CMAES_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Std', '-ascii');
        file_name=sprintf('Max\\CMAES_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Max', '-ascii');
        file_name=sprintf('Min\\CMAES_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Min', '-ascii');
        file_name=sprintf('Median\\CMAES_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Median', '-ascii');
        
        file_name=sprintf('Results\\CMAES_CEC2017_Problem#%s_problemSize#%s',int2str(func),int2str(problem_size));
        save(file_name,'outcome', 'allerrorvals');
        
        
        file_name=sprintf('Results\\CMAES_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'allerrorvals', '-ascii');
    end % end 1 func
end