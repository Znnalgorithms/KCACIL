function [Q,bestx,worstX] = RL(N, P1,P2,P3,,t,G,learning_rate,theta,Tmax,Tmin)      
d1=abs(P1(i,:)-best);
d2=abs(P2(i,:)-best);
d3=abs(P3(i,:)-best);
gama=0.5*(0.9-0.6*t/G);
delQ=Q-min(Q);

if 
    d1<min(d1) || d2<min(d2) || d3<min(d3);
    rew=1;
end
if 
   d2=min(d2) || d3=min(d3) || d1=min(d1);
    rew=0;
end
if 
    d1>min(d1) || d2>min(d2) || d3>min(d3);;
    rew=-1;
end
Q=Q+learning_rate*(rew+gama*deltQ);
[~,idxx]=sort(Q);
best=idxx(1);
worst=idxx(end);
bestX=P(idxx(1),:);
worstX=P(idxx(end),:);
T=Tmin+theta*(T-Tmin);
e=exp(-delQ/T);
if rand<e
    inds=lu;
else
    inds=best;
end



