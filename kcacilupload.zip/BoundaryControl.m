function pop=BoundaryControl(pop,low,up)
[popsize,dim]=size(pop);
for i=1:popsize
    for j=1:dim                
       flag=rand<rand;
        if pop(i,j)<low(j) 
            if flag 
                pop(i,j)=low(j); 
            else
                pop(i,j)=rand*(up(j)-low(j))+low(j);
            end
        end        
        if pop(i,j)>up(j) 
            if flag
                pop(i,j)=up(j);  
            else
                pop(i,j)=rand*(up(j)-low(j))+low(j); 
            end 
        end
    end
end
return
function F=scale_factor1  
     F=randn;
     
return
function F=scale_factor2      
     F=trnd(1);
return