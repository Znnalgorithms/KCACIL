function F=scale_factor2      
     F=trnd(1);
return