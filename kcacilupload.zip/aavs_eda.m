%==========AAVS-EDA==========%
clc;
clear all;

format long;
format compact;

val_2_reach = 10^(-200);
fhd=@cec14_func;
runs = 25;
RecordFEsFactor = ...
    [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
    0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
progress = numel(RecordFEsFactor);% ����14

for problem_size = [10,30,50,100]
    max_nfes = 10000 * problem_size;%������۴���
    rand('seed', sum(100 * clock));
    lu = [-100 * ones(1, problem_size); 100 * ones(1, problem_size)];
    fprintf('Running algorithm\n')
    
    for func = 1:30
        optimum = func * 100.0;
        %% Record the best results
        outcome = [];
        
        fprintf('\n-------------------------------------------------------\n')
        fprintf('Function = %d, Dimension size = %d\n', func, problem_size)
        
        allerrorvals = zeros(progress, runs);%��¼14����
        for run_id = 1 : runs
            
            run_funcvals = [];
            nfes = 0;
            
            %% ��������
            pop_size = 1000;
            tao = 0.35;
            alpha = 1.7;
            beta = 1/alpha;
            popold = repmat(lu(1, :), pop_size, 1) + rand(pop_size, problem_size) .* (repmat(lu(2, :) - lu(1, :), pop_size, 1));
            pop = popold;
            fitness = feval(fhd,pop',func);
            fitness = fitness';
            bsf_fit_var = 1e+30;
            bsf_index = 0;
            bsf_solution = zeros(1, problem_size);
            %%%%%%%%%%%%%%%%%%%%%%%% for out
            for i = 1 : pop_size
                nfes = nfes + 1;
                if fitness(i) < bsf_fit_var %&& isreal(pop(i, :)) && sum(isnan(pop(i, :)))==0 && min(pop(i, :))>=-100 && max(pop(i, :))<=100)
                    bsf_fit_var = fitness(i);
                    bsf_solution = pop(i, :);
                    bsf_index = i;
                end
                
                if nfes > max_nfes;
                    break;
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%% for out
            
            run_funcvals = [run_funcvals;ones(pop_size,1)*bsf_fit_var];
            
            g = 1;
            while nfes < max_nfes
                C = {};
                ct = 0;
                
                Sup_Pop = [];
                NN = pop_size * tao;
                %% ѡ�����Ƹ��壨�ض�ѡ��
                [FitnessValue,index]=sort(fitness);
                i=1:NN;
                Sup_Pop(i,:) = pop(index(i),:);
                %% ����ģ��
                mu = mean(Sup_Pop,1);
                %                 for i = 1 : size( Sup_Pop, 1)
                %                     C{i,i} = ((Sup_Pop(i,:) - mu)' * (Sup_Pop(i,:) - mu));
                %                 end
                %
                %                 for i=1:size(C);
                %                     ct = ct + C{i,i};
                %                 end
                ct = (Sup_Pop - repmat(mu,size(Sup_Pop,1),1))' * (Sup_Pop - repmat(mu,size(Sup_Pop,1),1));
                
                
                ct = ct/size( Sup_Pop, 1);
                %% Algorithm 2 (AAVS)
                [V,D] = eig(ct);
                f_mu = feval(fhd,mu',func);
                for i = 1 : size(ct,2)
                    %                     delta(i,:) = 0 + D(i,i) .* randn;
                    delta(i,:) = normrnd(0,D(i,i));
                    l(i,:) = mu - delta(i,:) .* V(:,i)';
                    r(i,:) = mu + delta(i,:) .* V(:,i)';
                end
                %                 l = boundConstraint(l,lu);         % ������
                %                 r = boundConstraint(r,lu);
                %% ������Ӧ��ֵ
                fitness2 = feval(fhd,l',func);
                fitness2 = fitness2';
                fitness3 = feval(fhd,r',func);
                fitness3 = fitness3';
                %%%%%%%%%%%%%%%%%%%%%%%% for out
                %                 for i = 1 : size(l,1)
                %                     nfes = nfes + 2;
                %                     if nfes > max_nfes;
                %                         break;
                %                     end
                %                 end
                %%%%%%%%%%%%%%%%%%%%%%%% for out
                f_mu = feval(fhd,mu',func);
                for i = 1 : size(l,1)
                    if (f_mu > min(fitness2(i),fitness3(i))) && (f_mu < max(fitness2(i),fitness3(i)))
                        D(i,i) = alpha * D(i,i);
                    end
                end
                %ct = V * D * V';
                
                AFV(g) = mean(FitnessValue(1:NN));
                
                if g > 1
                    if AFV(g) < AFV(g-1)
                        D = D;               % (i,i)
                    else
                        D = beta .* D;
                    end
                end
                ct = V * D * V';
                pop_new = mvnrnd(mu,ct,pop_size-1);
                pop_new = [pop_new;bsf_solution];
                pop_new = boundConstraint2(pop_new,popold,lu);
                popold = pop;
                %pop_new = boundConstraint(pop_new,lu);
                %% ������Ӧ��ֵ
                fitness4 = feval(fhd,pop_new',func);
                fitness4 = fitness4';
                %%%%%%%%%%%%%%%%%%%%%%%% for out
                for i = 1 : pop_size
                    nfes = nfes + 1;
                    if fitness4(i) < bsf_fit_var %&& isreal(pop_new(i, :)) && sum(isnan(pop_new(i, :)))==0 && min(pop_new(i, :))>=-100 && max(pop_new(i, :))<=100)
                        bsf_fit_var = fitness4(i);
                        bsf_solution = pop_new(i, :);
                        bsf_index = i;
                    end
                    
                    if nfes > max_nfes;
                        break;
                    end
                end
                %%%%%%%%%%%%%%%%%%%%%%%% for out
                
                run_funcvals = [run_funcvals;ones(pop_size,1)*bsf_fit_var];
                
                fitness = fitness4;
                pop = pop_new;
                
                g = g + 1;
            end% end nfes
            %% Violation Checking
            %             if(max(bsf_solution)>100)
            %                 fprintf('%d th run, Above Max\n', run_id)
            %             end
            %
            %             if(min(bsf_solution)<-100)
            %                 fprintf('%d th run, Below Min\n', run_id)
            %             end
            %
            %             if(~isreal(bsf_solution))
            %                 fprintf('%d th run, Complix\n', run_id)
            %             end
            
            bsf_error_val = abs(bsf_fit_var - optimum);
            %             if bsf_error_val < val_2_reach
            %                 bsf_error_val = 0;
            %             end
            
            if(sum(isnan(bsf_solution))>0)
                fprintf('%d th run, NaN\n', run_id)
            end
            %% �������ʾ
            fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , bsf_error_val)
            outcome = [outcome bsf_error_val];
            
            %% From Noor Code ( print files )
            errorVals= [];
            for w = 1 : progress
                bestold = run_funcvals(RecordFEsFactor(w) * max_nfes) - optimum;
                if abs(bestold)>1e-200
                    errorVals(w)= abs(bestold);
                else
                    bestold=0;
                    errorVals(w)= bestold;
                end
            end
            allerrorvals(:, run_id) = errorVals;
        end% end 1 run
        fprintf('\n')
        fprintf('min error value = %1.8e, max = %1.8e, median = %1.8e, mean = %1.2e, std = %1.2e\n', min(outcome), max(outcome), median(outcome), mean(outcome), std(outcome))
         Mean=mean(allerrorvals(end,:));
        Std=std(allerrorvals(end,:));
        Max=max(allerrorvals(end,:));
        Min=min(allerrorvals(end,:));
        Median=median(allerrorvals(end,:));
        fprintf('Mean =%g Std=%g max =%g min=%g median =%g\n',mean(allerrorvals(end,:)),std(allerrorvals(end,:)),max(allerrorvals(end,:)), min(allerrorvals(end,:)), median(allerrorvals(end,:)));
        file_name=sprintf('Mean\\AAVS_EDA_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Mean', '-ascii');
        file_name=sprintf('Std\\AVS_EDA_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Std', '-ascii');
        file_name=sprintf('Max\\AAVS_EDA_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Max', '-ascii');
        file_name=sprintf('Min\\AAVS_EDA_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Min', '-ascii');
        file_name=sprintf('Median\\AAVS_EDA_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'Median', '-ascii');
        
%         file_name=sprintf('Results\\CMAES_CEC2017_Problem#%s_problemSize#%s',int2str(func),int2str(problem_size));
%         save(file_name,'outcome', 'allerrorvals');
%         
%         
%         file_name=sprintf('Results\\CMAES_%s_%s.txt',int2str(func),int2str(problem_size));
%         save(file_name, 'allerrorvals', '-ascii');
        
        file_name=sprintf('Results\\AAVS_EDA_CEC2017_Problem#%s_problemSize#%s',int2str(func),int2str(problem_size));
        save(file_name,'outcome', 'allerrorvals');
        
        
        file_name=sprintf('Results\\AAVS_EDA_%s_%s.txt',int2str(func),int2str(problem_size));
        save(file_name, 'allerrorvals', '-ascii');
    end%end 1 func
end


