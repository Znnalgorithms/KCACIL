function fitnessBest = BSO(func,N,D,M,L,R,T)%funΪ����������ڴ�ָ���㺯��
runNum = 10;
pbest = zeros(T,runNum);
gbest = zeros(runNum,T);
fprintf('Function = %d, Dimension size = %d\n', func, D);
for run = 1:runNum
    best = zeros(M,1);
    centers = L + rand(M,D)*(R-L);%��ʼ��ÿ�����е����ֵ
    centersCopy = L + rand(M,D)*(R-L);
    xProb = zeros(M,1);
    fitnessBest = 1000000*ones(T,1);
    fitness = 1000000*ones(N,1);
    fitnessSorted = 1000000*ones(N,1);
    fitnessElitistSorted = 10000*ones(N,1);
    indexOriginal = ones(N,1);
    xElitist = L + rand(10,D)*(R-L);   
    inditempX = zeros(1,D);
    xSorted = L + rand(N,D)*(R-L);
    mutation1=zeros(N,1);
    mutation2=zeros(N,1);
    mutation3=zeros(N,1);
    mutation4=zeros(N,1);
    mutation5=zeros(N,1);
    oldx = L + rand(N,D)*(R-L);
    %%
    %��һ�����������N������
    x = L + rand(N,D)*(R-L);
    %%
    %�ڶ���������N������
    for i = 1:N
        fitness(i,1) = ObjFun(x(i,:),func);
    end
    %%
    for t = 1:T
        CP = 0.9-0.2*exp(1-T/(T-t+1));     
        [fitnessElitistSorted,indexOriginal] = sort(fitness,'ascend');%�����尴����Ӧ��ֵ��������
        xElitist = x(indexOriginal(1:10),:);        
        %������������k-means��ֵ���࣬��N���������ΪM����
        cluster = kmeans(x,M,'Distance','cityblock','Start',centers,'EmptyAction','singleton');
        %���Ĳ�����ÿ�����и���������򣬲���ÿ���������Ÿ����¼Ϊ������
        numberInCluster = zeros(M,1);
        fitnessValue = 1000000000000000*ones(M,1);
        for i=1:N
            numberInCluster(cluster(i,1),1) = numberInCluster(cluster(i,1),1) + 1;
            if fitnessValue(cluster(i,1),1) > fitness(i,1)
                fitnessValue(cluster(i,1),1) = fitness(i,1);
                best(cluster(i,1),1) = i;
            end
        end
        counterCluster = zeros(M,1);
        numberInClusterPre = zeros(M,1);       
        for i = 2:M  %�Դ��и����������
            numberInClusterPre(i,1) = numberInClusterPre(i-1,1) + numberInCluster(i-1,1);
        end
        %������Ⱥ
        for i = 1:N
            counterCluster(cluster(i,1),1) = counterCluster(cluster(i,1),1)+1;
            temIndex = numberInClusterPre(cluster(i,1)) + counterCluster(cluster(i,1),1);
            xSorted(temIndex,:) = x(i,:);
            fitnessSorted(temIndex,1) = fitness(i,1);
        end
        %��¼ÿ��������Ѹ���
        for m=1:M
            centers(m,:)= x(best(m,1),:);
        end
        centersCopy = centers;
        
        for i = 1:M
            xProb(i,1) = numberInCluster(i,1)/N;
            if i > 1
                xProb(i,1) = xProb(i,1) + xProb(i-1,1);
            end
        end
    
        %�������������¸��壺ʹ��Ⱥ����δ��������
        if t<=1           
            if rand<rand
                oldx = x;
            end
            for i = 1:N                
                r = rand();
                if r < 0.6
                    if rand() < 0.6
                        mutationStrategy = 1;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);
                        mutation1(i,1)=i;                       
                    else
                        mutationStrategy = 2;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);                                              
                        mutation2(i,1)=i;
                    end
                else
                    if rand < 0.8
                        mutationStrategy = 3;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);                       
                        mutation3(i,1)=i;
                    end
                    if rand < 1
                        mutationStrategy = 4;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);                                       
                        mutation4(i,1)=i;
                    end

                end %end if
                               
                jRand=randi([1,D]);%jRand��[1,D]
                for j=1:D
                    k=rand;
                    if k<=CP||j==jRand %j==jRand��Ϊ��ȷ��������һ��U(i,j)=V(i,j)
                        inditempX(1,j)=inditempX(1,j);
                    else
                        inditempX(1,j)=x(i,j);
                    end
                end
                
                fv =  ObjFun(inditempX,func);
                if fv < fitness(i,1)
                    fitness(i,1) = fv;
                    x(i,:) = inditempX(1,:);
                    flag = 1;
                else
                    flag =0;
                end
                ind(i)=flag;               
            end %����N��������½���
                        
            %�ҵ�4�������еĸ����±�
            ind1=find(mutation1);
            ind2=find(mutation2);
            ind3=find(mutation3);
            ind4=find(mutation4);
            
            indnum1 = ind(ind1);%4����������������ֻ��0��1
            indnum2 = ind(ind2);
            indnum3 = ind(ind3);
            indnum4 = ind(ind4);
            num1 = sum(indnum1==1);%4������1�ĸ���
            num2 = sum(indnum2==1);
            num3 = sum(indnum3==1);
            num4 = sum(indnum4==1);
            size1 = size(ind1,1);%4�������ָ������Ŀ
            size2 = size(ind2,1);
            size3 = size(ind3,1);
            size4 = size(ind4,1);
            P1 = num1 / size1;
            P2 = num2 / size2;
            P3 = num3 / size3;
            P4 = num4 / size4;
            [~,index]=max([P1,P2,P3,P4]);
            %�ҵ�4����������Ӧ��ֵ��С�ĸ���
            if any(index==1)
                tempx=x(ind1,:);
                tempfit=fitness(ind1);
                [~,index1]=min(tempfit);
                mutX_copy=tempx(index1,:);
            end
            if any(index==2)
                tempx=x(ind2,:);
                tempfit=fitness(ind2);
                [~,index2]=min(tempfit);
                mutX_copy=tempx(index2,:);
            end
            if any(index==3)
                tempx=x(ind3,:);
                tempfit=fitness(ind3);
                [~,index3]=min(tempfit);
                mutX_copy=tempx(index3,:);
            end
            if any(index==4)
                tempx=x(ind4,:);
                tempfit=fitness(ind4);
                [~,index4]=min(tempfit);
                mutX_copy=tempx(index4,:);
            end
            mutation1=zeros(N,1);
            mutation2=zeros(N,1);
            mutation3=zeros(N,1);
            mutation4=zeros(N,1);
            %Ϊÿ���ر�����õ�
            for i = 1:M
                x(best(i,1),:) = centersCopy(i,:);
                fitness(best(i,1),1) = fitnessValue(i,1);
            end              
            
        %t>2ʱ,ÿһ��ÿһ�����嶼���¸���
        else
            if rand<rand
                oldx=x;
            end
            for i = 1:N                
                R_mat_x1_y = corrcoef(mutX_copy,x(i,:));
                R = R_mat_x1_y(2);
                if R == 1 %�������                  
                    if index == 1
                        mutationStrategy = 1;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);
                        mutation1(i,1)=i;
                    end
                    if index == 2
                        mutationStrategy = 2;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);                        
                        mutation2(i,1)=i;
                    end
                    if index == 3
                        mutationStrategy = 3;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);
                        mutation3(i,1)=i;
                    end
                    if index == 4
                        mutationStrategy = 4;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);                       
                        mutation4(i,1)=i;
                    end
                else%������ǿ���                    
                    a = randperm(5);
                    indexmin = a(1,1);
                    if indexmin == index
                        indexmin = a(1,5);
                    end
                    
                    if indexmin == 1
                        mutationStrategy = 1;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);
                        mutation1(i,1)=i;
                    end
                    if indexmin == 2
                        mutationStrategy = 2;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);
                        mutation2(i,1)=i;
                    end
                    if indexmin == 3
                        mutationStrategy = 3;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);
                        mutation3(i,1)=i;
                    end
                    if indexmin == 4
                        mutationStrategy = 4;
                        inditempX(1,:) = mutation(x,oldx,M,N,D,T,t,xProb,numberInClusterPre,numberInCluster,xSorted,xElitist,centers,mutationStrategy);
                        mutation4(i,1)=i;
                    end     
                end
                  
                
                jRand=randi([1,D]);%jRand��[1,D]
                for j=1:D
                    k=rand;
                    if k<=CP||j==jRand %j==jRand��Ϊ��ȷ��������һ��U(i,j)=V(i,j)
                        inditempX(1,j)=inditempX(1,j);
                    else
                        inditempX(1,j)=x(i,j);
                    end
                end
                fv =  ObjFun(inditempX,func);
                if fv < fitness(i,1)
                    fitness(i,1) = fv;
                    x(i,:) = inditempX(1,:);
                    flag = 1;
                else
                    flag = 0;                    
                end
                ind(i) = flag;             
            end  % end i=!1:N
            
            ind1=find(mutation1);
            ind2=find(mutation2);
            ind3=find(mutation3);
            ind4=find(mutation4);
            
            indnum1 = ind(ind1);%4����������������ֻ��0��1
            indnum2 = ind(ind2);
            indnum3 = ind(ind3);
            indnum4 = ind(ind4);
            num1 = sum(indnum1==1);%4������1�ĸ���
            num2 = sum(indnum2==1);
            num3 = sum(indnum3==1);
            num4 = sum(indnum4==1);
            size1 = size(ind1,1);%4�������ָ������Ŀ
            size2 = size(ind2,1);
            size3 = size(ind3,1);
            size4 = size(ind4,1);
            P1 = num1 / size1;
            P2 = num2 / size2;
            P3 = num3 / size3;
            P4 = num4 / size4;
            [~,index]=max([P1,P2,P3,P4]);
            if any(index==1)
                tempx=x(ind1,:);
                tempfit=fitness(ind1);
                [~,index1]=min(tempfit);
                mutX_copy=tempx(index1,:);
            end
            if any(index==2)
                tempx=x(ind2,:);
                tempfit=fitness(ind2);
                [~,index2]=min(tempfit);
                mutX_copy=tempx(index2,:);
            end
            if any(index==3)
                tempx=x(ind3,:);
                tempfit=fitness(ind3);
                [~,index3]=min(tempfit);
                mutX_copy=tempx(index3,:);
            end
            if any(index==4)
                tempx=x(ind4,:);
                tempfit=fitness(ind4);
                [~,index4]=min(tempfit);
                mutX_copy=tempx(index4,:);
            end           
            mutation1=zeros(N,1);
            mutation2=zeros(N,1);
            mutation3=zeros(N,1);
            mutation4=zeros(N,1);
            %Ϊÿ���ر�����õ�
            for i = 1:M
                x(best(i,1),:) = centersCopy(i,:);
                fitness(best(i,1),1) = fitnessValue(i,1);
            end            
        end %end if
        
    fitnessBest = min(fitnessValue);
    gval = fitnessBest-100*func;
    pbest(t,run) = gval;
    gbest(run,t) = gval;    
    
%     fprintf('BSO|%5.0f -----> %9.16f\n',t,gval);
    end %end T
    %T�ε������,һ�����н���
        
      fprintf('BSO|%5.0f -----> %9.16f\n',run,fitnessBest);
%     if D==10  %pbest �洢 T*runNum ����ֵ
%         xlswrite('RLBSO_10D.xlsx',pbest,func);
%     end
%     if D==30
%         xlswrite('RLBSO_30D.xlsx',pbest,func);
%     end
    if D==50
        xlswrite('RLBSO_50D.xlsx',pbest,func);
    end
    if D==100
        xlswrite('RLBSO_100D.xlsx',pbest,func);
    end
    file_name=sprintf('gbest\\RLBSO_%s_%s.txt',int2str(func),int2str(D));
%     save(file_name, 'gval', '-ascii','-append'); 
    
end  % end runtime
  Mean=mean(gbest(:,end));
  Std=std(gbest(:,end));
 fprintf('Mean =%g Std=%g max =%g min=%g median =%g\n',Mean,Std,max(gbest(:,end)), min(gbest(:,end)), median(gbest(:,end)));
% file_name=sprintf('Mean\\RLBSO_%s_%s.txt',int2str(func),int2str(D));
% save(file_name, 'Mean', '-ascii');%��ֵmean
% file_name=sprintf('Std\\RLBSO_%s_%s.txt',int2str(func),int2str(D));
% save(file_name, 'Std', '-ascii');%����standard variance