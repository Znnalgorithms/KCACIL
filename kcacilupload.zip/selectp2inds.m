function [p] = selectp2inds(N, P,fitnessP1,fitnessP2,fitnessP3,d2)   
p2=(1-(sum(fitnessP2))/sum(fitnessP1+fitnessP2+fitnessP3))^2;
 
 [~,idx11]=sort(d1);
 [bestX2,idx2]=min(fitnessP2);
 NN2=round((p2*N)-1);
 i=1:NN2;
  pbest1 = P((idx11(i)-1),:);
  pbest2=[pbest1,bestX2]