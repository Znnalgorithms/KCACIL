function [r1,r2] = gnR1R22(NP1, NP2, r0)
NP0 = length(r0);
% r1 = floor(rand(1, NP0) * NP1) + 1;
r1 = randperm(NP1,NP0);
%for i = 1 : inf
for i = 1 : 10000
    pos = (r1 == r0);
    if sum(pos) == 0
        break;
    else 
%         r1(pos) = floor(rand(1, sum(pos)) * NP1) + 1;
        r1(pos) = randperm(NP1,sum(pos));
    end
    if i > 1000 
        error('Can not genrate r1 in 1000 iterations');
    end
end

% r2 = floor(rand(1, NP0) * NP2) + 1;
r2 = randperm(NP2,NP0);
%for i = 1 : inf
for i = 1 : 10000
    pos = ((r2 == r1) | (r2 == r0));
    if sum(pos)==0
        break;
    else 
        % r2(pos) = floor(rand(1, sum(pos)) * NP2) + 1;
        r2(pos) = randperm(NP2,sum(pos));      
    end
    if i > 1000 
        error('Can not genrate r2 in 1000 iterations');
    end
end
