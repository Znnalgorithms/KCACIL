function [F1,CR1,P] = randFCR1(N,dim, CRm, CRsigma, Fm, Fsigma,t,G,fitnessP1,fitnessP2,fitnessP3)   
cc=0.9-0.9*10^(-5)*t/G;
w=deltafitnessP1/sum(deltafitnessP1+deltafitnessP2+deltafitnessP3);
CRm=(1-cc)*CRm+cc*mean(w*CR1);

CR1 = min(1, max(0, CR1));              
%%%
Fm=(1-cc)*Fm+cc*mean(w*F1);


% F = randCauchy(NP, 1, Fm, Fsigma);    
F1 = min(1, F1);
pos = find(F1 <= 0);
while ~ isempty(pos)
%     F(pos) = randCauchy(length(pos), 1, Fm, Fsigma);
    F1(P) = normrnd(length(pos),1,Fm,Fsigma); 
    F1 = min(1, F1);                      % truncation
    pos = find(F1 <= 0);
end
 r0 = (1 : N);
               
 [r1, r2] = gnR1R22(N, size(P1, 1), r0);
%  b = F1(:, ones(1, problem_size));
                vi = P1 + F1 .* (pbest1 - P1 + P1(r1, :) - P1(r2, :));
                vi = boundConstraint2(vi, P1, lu);
                %% 
                mask = rand(N, dim) > CR(:, ones(1, dim)); 
                rows = (1 : N)';
                cols = floor(rand(N, 1) * dim)+1;                
                jrand = sub2ind([N dim], rows, cols);           
                mask(jrand) = false;
                u1 = vi;
                u1(mask) = P1(mask);
                %% 
                % I == 1: the parent is better; I == 2: the offspring is better
%                 fitnessP=ObjFun(P,func);
                fitnessU1 = ObjFun(u1(:,1:dim)',func);
                fitnessU1 = fitnessU1';
                
                %% 
% %                 archive = updateArchive2(archive,P1(I == 2, :), U1(I == 2));
% %                 P1(I == 2, :) = ui(I == 2, :);
% %                 goodCR = CR(I == 2);
% %                 goodF = F(I == 2);
                %%%%%%%%%%%%%%%%%%%%%% for out
                
                    if u1 < bsf_fit_var
                        bsf_fit_var = u1;
                        bsf_solution = P1(i, :);
                        bsf_index = i;
                    end
                    K=sum(fitnessP1)/N;
                    KK=sum(fitnessU1)/N;
                    if KK<K
                        CR1=cc*CR1+(1-cc)*CR1;
                        F1=cc*F1+(1-cc)*F1;
                    else
                        F1 = normrnd(Fm,Fsigma,[NP,1]); 
                        CR1 = normrnd(CRm,CRsigma,[NP,1]);   
                    end
% Cauchy distribution: cauchypdf = @(x, mu, delta) 1/pi*delta./((x-mu).^2+delta^2)
%% 
% function result = randCauchy(m, n, mu, delta)
% result = mu + delta * tan(pi * (rand(m, n) - 0.5));
% %result = tan(pi * (rand(m, n) - 0.5));
