clear;
clc;
warning off all
fhd = @cec17_func;
N=100;
M=5;
L=-100;
R=100;
D=10;
T = 2000;
cpu_t2=zeros(5,1);
for i=1:5
tic
for func=18
    LSHADE(func,N,D,M,L,R,T);
end
t2=toc;
cpu_t2(i,1)=t2;
end
file_name=sprintf('CPU_T_LSHADE_%s_%s.txt',int2str(func),int2str(D));
save(file_name,'cpu_t2','-ascii','-append');